import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usgs',
  templateUrl: './usgs.component.html',
  styleUrls: ['./usgs.component.css']
})
export class UsgsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
