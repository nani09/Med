import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule }    from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { PrescriptionsComponent } from './prescriptions/prescriptions.component';
import { XraysComponent } from './xrays/xrays.component';
import { MrisComponent } from './mris/mris.component';
import { UsgsComponent } from './usgs/usgs.component';
import { BloodreportsComponent } from './bloodreports/bloodreports.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    PrescriptionsComponent,
    XraysComponent,
    MrisComponent,
    UsgsComponent,
    BloodreportsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
