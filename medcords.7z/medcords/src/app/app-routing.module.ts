import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PrescriptionsComponent } from './prescriptions/prescriptions.component';
import { XraysComponent } from './xrays/xrays.component';
import { UsgsComponent } from './usgs/usgs.component';
import { MrisComponent } from './mris/mris.component';
import { BloodreportsComponent } from './bloodreports/bloodreports.component';

const routes: Routes = [ 
  {path: 'home', 
    children:[
      {path:'', component: HomeComponent},
      {path:'prescriptions', component: PrescriptionsComponent}  ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
