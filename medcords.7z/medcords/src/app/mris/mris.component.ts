import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mris',
  templateUrl: './mris.component.html',
  styleUrls: ['./mris.component.css']
})
export class MrisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
