import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bloodreports',
  templateUrl: './bloodreports.component.html',
  styleUrls: ['./bloodreports.component.css']
})
export class BloodreportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
