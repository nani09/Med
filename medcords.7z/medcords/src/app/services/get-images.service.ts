import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import {map} from 'rxjs/operators' ;
import { Observable, Subject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GetImagesService {

  subject = new Subject<string>();

  constructor( private http :  HttpClient) { 
    // console.log(this.subject.subscribe(p => p))
  }

  getImages() :Observable<string[]>{
    return this.http.get("assets/response.json").pipe(map(res => res["images"]))
  }

}
