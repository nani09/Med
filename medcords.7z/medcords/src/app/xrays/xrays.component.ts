import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-xrays',
  templateUrl: './xrays.component.html',
  styleUrls: ['./xrays.component.css']
})
export class XraysComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
