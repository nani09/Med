import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { GetImagesService }  from '../services/get-images.service';


@Component({
  selector: 'app-prescriptions',
  templateUrl: './prescriptions.component.html',
  styleUrls: ['./prescriptions.component.css']
})
export class PrescriptionsComponent implements OnDestroy {
  images: any[] = [];
  subscription: Subscription;

  constructor(private getImageService:GetImagesService) {
     this.getImageService.subject.subscribe(p => console.log(p))
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  display(){
    console.log(this.images)
  }

}
